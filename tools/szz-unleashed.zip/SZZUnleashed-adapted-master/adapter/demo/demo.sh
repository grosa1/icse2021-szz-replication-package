#!/bin/bash

unzip adapter/demo/repos_demo.zip -d adapter/demo/

docker build -f Dockerfile.adapter -t szz-unleashed-adapted . && \
docker run \
      --name szz-unleashed-adapted_1 \
      -v $(pwd)/adapter/demo/input_demo.json:/tmp/adapter/input_file.json:ro \
      -v $(pwd)/adapter/output:/tmp/adapter/output/ \
      -v $(pwd)/adapter/demo/repos_demo:/tmp/adapter/repository_folder/ \
      szz-unleashed-adapted

